jQuery.sap.declare("zsj_workcenter.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("zsj_workcenter.Component", {
	metadata: {
		"manifest": "json"
	}
});